package com.service;

import java.util.List;

import com.domain.Book;



public interface IBookStoreService {
	
	Book save(Book book);
	Book update(Book book);
	void delete(int id);
	List<Book> getAllBooks();

}
