package com.mphasis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.entity.Book;

public interface BookRepositiry extends JpaRepository<Book, Long> {

	Book findByName(String name);
}
