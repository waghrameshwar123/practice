package com.mphasis.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.entity.Book;
import com.mphasis.service.BookService;

/**
 * @author labuser
 *
 */
@RestController
public class BookController {
	
	@Autowired
	private BookService service;
	
	@PostMapping("/addBook")
	public Book saveBook(@RequestBody Book b) {
		return service.save(b);
		
	}
	
	@PostMapping("/addBooks")
	public List<Book> addBooks(@RequestBody List<Book> b){
		return service.saveBooks(b);
	}
	
	@GetMapping("/getBooks")
	public List<Book> getBooks(){
		return service.getBooks();
	}
	
	@GetMapping("getBook/{id}")
	public Optional<Book> geBookById(@PathVariable long id) {
		return service.getBookById(id);
				
	}
	
	@GetMapping("getBookByName/{name}")
	public Book geBookByName(@PathVariable String name) {
		return service.getBookByName(name);
				
	}
	@PutMapping("/delete/{id}")
	public String deletBook(@PathVariable Long id) {
		return service.delete(id);
	}
	


	


}
