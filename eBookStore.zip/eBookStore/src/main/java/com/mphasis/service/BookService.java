package com.mphasis.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mphasis.entity.Book;
import com.mphasis.repository.BookRepositiry;

@Service
public class BookService {
	
	private BookRepositiry repository;
	
	public void setRepository(BookRepositiry repositiry) {
		this.repository = repositiry;
	}
	
	public List<Book> getBooks(){
		return repository.findAll();
	}
	
	public Book save(Book b) {
		return repository.save(b);
	}
	
	public List<Book> saveBooks(List<Book> b){
		return repository.saveAll(b);
	}
	
	public String delete(Long id) {
	 	repository.deleteById(id);
		return null;
	}
	public Book getById(Long id) {
		return repository.getOne(id);
	}

	public Optional<Book> getBookById(long id) {
		return repository.findById((long) id);
	}
	
	public Book getBookByName(String name) {
		return repository.findByName(name);
	}

}
