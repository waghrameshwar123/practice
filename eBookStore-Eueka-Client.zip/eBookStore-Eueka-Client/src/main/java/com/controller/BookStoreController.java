package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Book;
import com.service.IBookStoreService;

@RestController
@Scope("request")
public class BookStoreController {

	@Autowired
	@Qualifier("bookstoreService")
	private IBookStoreService bookstoreService;
	
	@RequestMapping("/")
	public String Home() {
		return "Welcome To BookStore Portal";
	}
	
	@GetMapping(value = "/book", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getAllBooks(){
		return bookstoreService.getAllBooks();
		
	}
	
	@GetMapping(value="/bookbyid/{id}", produces = {MediaType.APPLICATION_JSON_VALUE}) 
	public Book getBookById(@PathVariable int id){ 
		return bookstoreService.getBookById(id); 

	} 

	@GetMapping(value="/bookbyname/{name}", produces = {MediaType.APPLICATION_JSON_VALUE}) 
	public List<Book> getProductByname(@PathVariable String name){ 
	return bookstoreService.getAllBooksByName(name); 
	} 
}
