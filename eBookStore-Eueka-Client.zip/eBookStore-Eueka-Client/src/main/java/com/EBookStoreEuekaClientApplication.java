package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.domain.Book;
import com.repository.BookRepository;

@EnableEurekaClient
@SpringBootApplication
public class EBookStoreEuekaClientApplication implements CommandLineRunner{
	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepository;

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreEuekaClientApplication.class, args);
		System.out.println("Eureka Client is Running . . .");
	}
	
	@Override
	public void run(String... args) throws Exception {
	
		bookRepository.save(new Book(101, "Core Java", "Mphasis", 3500));
		bookRepository.save(new Book(102, "Oracle", "Mph", 2500));
		bookRepository.save(new Book(103, "Spring", "Yp", 3400));
		bookRepository.save(new Book(101, "Java Microservices", "Yog", 2800));
		System.out.println(bookRepository.findAll());
		
	}

}
