package com.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.domain.Book;
import com.proxy.BookServiceProxy;


@Component
public class BookServiceFallback implements BookServiceProxy{
	
	@Override
	public List<Book> getAllBooks(){
		return Arrays.asList(new Book());
	}
	@Override
	public Book BookById(int id) {
		return new Book(id,"SQL","sql.org",200);
		
	}

}
