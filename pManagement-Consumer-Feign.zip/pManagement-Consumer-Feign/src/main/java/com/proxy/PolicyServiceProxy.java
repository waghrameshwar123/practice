package com.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.domain.Policy;



@FeignClient("policy-service")
public interface PolicyServiceProxy {
	
	@GetMapping(value = "/policies/all", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Policy> findAll();
	
	@GetMapping(value = "/policies/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Policy findById(@PathVariable("id") long id);
	

}
