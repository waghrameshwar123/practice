package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Policy;
import com.proxy.PolicyServiceProxy;

@RestController
public class PolicyConsumerController {
	
	@Autowired
	private PolicyServiceProxy policyserviceProxy;
	
	@GetMapping("/policies/all")
	public List<Policy> list() {
        List<Policy>  policies= policyserviceProxy.findAll();
        return policies;
    };
	
	@GetMapping("/policies/{id}")
	public Policy getPolicyById(@PathVariable("id") long id) {
		Policy policy = policyserviceProxy.findById(id);
		return policy;
	}
}
