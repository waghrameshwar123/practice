package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.domain.Book;
import com.repository.BookRepository;



@SpringBootApplication
public class EBookStoreDockertApplication implements CommandLineRunner{
	
	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepository;

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreDockertApplication.class, args);
		System.out.println("********  Server Is Running ***********");
	}

	@Override
	public void run(String... args) throws Exception {
	
		bookRepository.save(new Book(101, "Core Java", "Mphasis", 3500));
		bookRepository.save(new Book(102, "Oracle", "Mph", 2500));
		bookRepository.save(new Book(103, "Spring", "Yp", 3400));
		bookRepository.save(new Book(104, "Java Microservices", "Yog", 2800));
		System.out.println(bookRepository.findAll());
		
	}

}
